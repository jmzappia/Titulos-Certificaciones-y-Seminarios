require('http').createServer((req,res) => res.end(`Hola soy el Server ${8000} - ${new Date().toLocaleString()}`)).listen(8000)
