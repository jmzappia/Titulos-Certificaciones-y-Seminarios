console.log('Bienvenidos al Webinar de JS')

document.querySelector('h1').innerHTML += ' <i style="color:purple;">Como están!</i>'
document.querySelector('h1').style.color = 'red'
document.querySelector('p').style.color = 'magenta'
document.querySelector('p').style.backgroundColor = 'black'
document.querySelector('body').style.backgroundColor = 'pink'

let ul = document.createElement('ul')
for(var i=0; i<5; i++) {
    ul.innerHTML += `<li>item${i+1}</li>`
}
document.body.appendChild(ul)

let items = document.querySelectorAll('li')
console.log(items)

for(var i=0; i<items.length; i++) {
    items[i].style.color = i%2? 'orange':'cyan'
    items[i].style.backgroundColor = i%2? 'brown':'blue'
}